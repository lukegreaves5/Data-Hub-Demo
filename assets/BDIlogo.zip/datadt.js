console.log('hello');

var city = document.getElementById('city');
var attendeeFunction = document.getElementById('attendeeFunction');
var content = document.getElementById('content');
var senior = document.getElementById('senior');

console.log('hello');

Array cityarr[];